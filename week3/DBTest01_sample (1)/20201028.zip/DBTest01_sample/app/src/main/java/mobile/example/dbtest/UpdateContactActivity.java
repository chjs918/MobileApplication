package mobile.example.dbtest;

import android.app.Activity;

public class UpdateContactActivity extends Activity {

}
